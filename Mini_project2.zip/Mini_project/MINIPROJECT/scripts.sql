-- Table: public.get_product_details

-- DROP TABLE IF EXISTS public.get_product_details;

CREATE TABLE IF NOT EXISTS public.get_product_details
(
    name character varying(100) COLLATE pg_catalog."default",
    productid integer,
    available_stocks integer,
    price_of_one_unit double precision,
    tax_percentage double precision
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.get_product_details
    OWNER to postgres;