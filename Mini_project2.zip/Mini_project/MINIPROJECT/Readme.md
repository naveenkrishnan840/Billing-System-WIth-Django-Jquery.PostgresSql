# Billing System Project
    This project is implement to django template framework
    Activate Source Code:
        source bin/activate
    Run Project:
        python manage.py runserver
    migration:
        python manage.py makemigrations
        python manage.py migrate
    Database Configuartion: 
        Postgres Sql
    