from django.db import models


class EmailDetails(models.Model):
	email_name = models.EmailField(max_length=100)

	class Meta:
		db_table = "tbl_emails"


class ProductDetails(models.Model):
	name = models.CharField(max_length=100)
	product_id = models.IntegerField(null=True)
	available_stocks = models.IntegerField(null=True)
	price_of_one_unit = models.FloatField(null=True)
	tax_percentage = models.FloatField(null=True)

	class Meta:
		db_table = "tbl_get_product_details"


class PurchasedItemByCustomer(models.Model):
	product_id = models.IntegerField(null=True)
	unit_price = models.FloatField(null=True)
	quantity = models.IntegerField(null=True)
	purchase_price = models.FloatField(null=True)
	tax_for_item = models.FloatField(null=True)
	tax_payable_for_item = models.FloatField(null=True)
	total_price_for_item = models.FloatField(null=True)
	email = models.ForeignKey(EmailDetails, on_delete=models.CASCADE, null=True)

	class Meta:
		db_table = "tbl_purchased_item_by_customer"