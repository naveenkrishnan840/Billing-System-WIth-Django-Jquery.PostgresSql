from django.apps import AppConfig


class BillingPaymentPagesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'billing_payment_pages'
