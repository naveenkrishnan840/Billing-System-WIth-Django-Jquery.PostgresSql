from django.urls import path
from . import views
urlpatterns = [
	path("", views.GetBilling_page.as_view(), name="get_Billing_page"),
	path("generate_bill", views.PostBilling_page.as_view(), name="post_Billing_page")
	
]