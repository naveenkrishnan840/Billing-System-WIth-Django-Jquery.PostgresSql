from django.shortcuts import render
from . import models
from django.views import *
from django.contrib import messages
import threading
from . import email_content
from django.core.mail import EmailMessage
from django.db.models import F
from collections import defaultdict

# Create your views here.


class GetBilling_page(View):
	def get(self, request):
		get_product_details = models.ProductDetails.objects.values("product_id", "name")
		purchased_products = models.PurchasedItemByCustomer.objects.annotate(\
			email_name=F("email__email_name")).values("email_name", "product_id")
		items_by_email = defaultdict(list)
		email = ""
		for i in purchased_products:
			if email != i["email_name"]:
				items_by_email[i["email_name"]].append(i["product_id"])
				email = i["email_name"]
		
		return render(request, "billing_page_one.html", context={"get_product_details": get_product_details,
		                                                         "items_by_email": items_by_email})


class PostBilling_page(View):
	def post(self, request, ):
		get_product_details = models.ProductDetails.objects.values("product_id", "name", "available_stocks")
		available_product_ids = [i["product_id"] for i in get_product_details]
		email = request.POST.get("email")
		Total_amount_by_customer = request.POST.get('total_amount')
		total_product_ids = request.POST.get("total_product_ids").split(",") \
			if request.POST.get("total_product_ids") not in "-" else ""
		if not email:
			messages.error(request, message="Email is required")
			return render(request, "billing_page_one.html", context={"get_product_details": get_product_details})
		if not total_product_ids:
			messages.error(request, message="Atleast one product is required")
			return render(request, "billing_page_one.html",
			              context={"get_product_details": get_product_details}
			              )
		else:
			for split_product in total_product_ids:
				if not split_product.split("-")[0]:
					messages.error(request, message="This Product Id is required")
					return render(request, "billing_page_one.html",
					              context={"get_product_details": get_product_details}
					              )
				elif int(split_product.split("-")[0]) not in available_product_ids:
					messages.error(request, message="This Product Id is not Available")
					return render(request, "billing_page_one.html",
					              context={"get_product_details": get_product_details}
					              )
				if not split_product.split("-")[1]:
					messages.error(request, message="This Quantity is required")
					return render(request, "billing_page_one.html",
					              context={"get_product_details": get_product_details}
					              )
				
				elif list(filter(lambda x: x["product_id"] == int(split_product.split("-")[0]), get_product_details)
				          )[0]["available_stocks"] < int(split_product.split("-")[1]):
					messages.error(request, message="This Quantity is not avialable stocks")
					return render(request, "billing_page_one.html",
					              context={"get_product_details": get_product_details}
					              )
				
				if Total_amount_by_customer == '0.00':
					messages.error(request, message="Total Amount is Required")
					return render(request, "billing_page_one.html",
					              context={"get_product_details": get_product_details}
					              )
				product_quantity = {int(i.split("-")[0]): int(i.split("-")[1]) for i in total_product_ids}
				purchased_products = product_quantity.keys()
				purchased_items = \
					[i for i in models.ProductDetails.objects.all() if i.product_id in purchased_products]
				dict_purchased_items = []
				total_price_without_tax = 0
				total_tax_payable = 0
				for item in purchased_items:
					items = {}
					unit_price = int(item.price_of_one_unit)
					quantityOfItem = [j for i, j in product_quantity.items() if str(i) in str(item.product_id)][0]
					purchased_price = unit_price * quantityOfItem
					total_price_without_tax += purchased_price
					taxpercenatge = item.tax_percentage
					tax_payable_item = purchased_price * (taxpercenatge / 100)
					total_tax_payable += tax_payable_item
					items.update(productId=item.product_id)
					items.update(UnitPrice=unit_price)
					items.update(Quantity=quantityOfItem)
					items.update(purchased_price=purchased_price)
					items.update(taxForItem=taxpercenatge)
					items.update(taxPayableItem=tax_payable_item)
					items.update(totalPayableItem=purchased_price + tax_payable_item)
					dict_purchased_items.append(items)
				net_price_of_the_purchased_items = total_price_without_tax + total_tax_payable
				Balance_payable_to_customer = int(Total_amount_by_customer.split(".")[0]
				                                  ) - net_price_of_the_purchased_items
				models.EmailDetails.objects.create(email_name=email)
				last_id = models.EmailDetails.objects.last().id
				for purchased_item in dict_purchased_items:
					row_items = models.PurchasedItemByCustomer(email_id=last_id,
					                                           product_id=purchased_item["productId"],
					                                           unit_price=purchased_item["UnitPrice"],
					                                           quantity=purchased_item["Quantity"],
					                                           purchase_price=purchased_item["purchased_price"],
					                                           tax_for_item=purchased_item["taxForItem"],
					                                           tax_payable_for_item=purchased_item["taxPayableItem"],
					                                           total_price_for_item=purchased_item["totalPayableItem"]
					                                           )
					row_items.save()
				balance_denomination = []
				label_denomination = [500, 50, 20, 10, 5, 2, 1]
				template_balance_denomination = {}
				Balance_payable_to_customer_copy = Balance_payable_to_customer
				for den in label_denomination:
					if den != 0:
						deno = str(Balance_payable_to_customer_copy / den).split(".")[0]
						if deno == "0":
							continue
						balance_denomination.append(deno)
						template_balance_denomination[den] = deno
						Balance_payable_to_customer_copy -= int(deno) * den
				thread = threading.Thread(target=send_to_mail,
				                          args=(email, dict_purchased_items, total_price_without_tax,
				                                total_tax_payable,
				                                net_price_of_the_purchased_items,
				                                Balance_payable_to_customer, template_balance_denomination)
				                          )
				thread.start()
				return render(request, "billing_page_two.html", context=dict(email=email,
				                                                             dict_purchased_items=dict_purchased_items,
				                                                             total_price_without_tax=total_price_without_tax,
				                                                             total_tax_payable=total_tax_payable,
				                                                             net_price_of_the_purchased_items=
				                                                             net_price_of_the_purchased_items,
				                                                             rounded_net_price_of_the_purchased_items=
				                                                             str(round(net_price_of_the_purchased_items)) + ".00",
				                                                             Balance_payable_to_customer=Balance_payable_to_customer,
				                                                             denominations=template_balance_denomination
				                                                             )
				              )


def send_to_mail(email, dict_purchased_items, total_price_without_tax, total_tax_payable,
                 net_price_of_the_purchased_items, balance_payable_to_customer, balance_denomination
                 ):
	message = ""
	message += email_content.email_content.format(email)
	for i in dict_purchased_items:
		message += email_content.tr_tags.format(str(i["productId"]), str(i["UnitPrice"]), str(i["Quantity"]),
		                                        str(i["purchased_price"]), str(i["taxForItem"]),
		                                        str(i["taxPayableItem"]), str(i["totalPayableItem"])
		                                        )
	message += email_content.footer_tags.format(str(total_price_without_tax), str(total_tax_payable),
	                                            str(net_price_of_the_purchased_items),
	                                            str(round(net_price_of_the_purchased_items)),
	                                            str(balance_payable_to_customer)
	                                            )
	message += email_content.balance_deno
	
	for i, j in balance_denomination.items():
		message += email_content.loop_balance.format(i, j)
	msg = EmailMessage(subject="Billing System", body=message, from_email="naveenkrishnan840@gmail.com",
	                   to=[email])
	msg.content_subtype = "html"
	msg.send()
