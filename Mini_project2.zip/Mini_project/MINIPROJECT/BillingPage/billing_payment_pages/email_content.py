email_content = "<!DOCTYPE html><html lang='en'><body>" \
                "<div style='text-align:center; font-size:25px;'><p><b>Billing Page</b></p></div><div><div>" \
                "<label>Customer Email: </label> <span>{0}</span></div><br><br><div><p> Bill section</p>" \
                "<table style='table-layout: fixed; width:100%; border: 2px solid black; border-collapse: collapse;'>" \
                "<tbody><thead> <tr><th style='border:1px solid black; text-align:center;'>Product ID</th>" \
                "<th style='border:1px solid black; text-align:center;'>Unit Price</th>" \
                "<th style='border:1px solid black; text-align:center;'>Quantity</th>" \
                "<th style='border:1px solid black; text-align:center;'>Purchase Price</th>" \
                "<th style='border:1px solid black; text-align:center;'>Tax % For Item</th>" \
                "<th style='border:1px solid black; text-align:center;'>Tax Payable For Item</th>" \
                "<th style='border:1px solid black; text-align:center;'>Total Price Of The Item</th></tr></thead>"
tr_tags = "<tr><td style='border:1px solid black; text-align:center;'>{0}</td>" \
          "<td style='border:1px solid black; text-align:center;'>{1}</td>" \
          "<td style='border:1px solid black; text-align:center;'>{2}</td>" \
          "<td style='border:1px solid black; text-align:center;'>{3}</td>" \
          "<td style='border:1px solid black; text-align:center;'>{4}</td><td>{5}</td>" \
          "<td style='border:1px solid black; text-align:center;'>{6}</td></tr>"
footer_tags = "</tbody></table><br><br><div style='position: relative; left:1000px;'>" \
              "<p>Total price without tax: <span>{0}</span></p><p>Total tax payable: <span>{1}</span></p>" \
              "<p>Net price of the purchased item: <span>{2}</span></p>" \
              "<p>Rounded down of the purchased items net price: <span>{3}</span></p>" \
              "<p>Balance payable to the customer: <span>{4}</span></p></div><br><hr><br>"

balance_deno = "<div style=position: relative; left:1000px;'><span style=position: relative; right:100px;'> " \
               "Balance Denomination: "
loop_balance = "</span><p>{0}:<span>{1}</span></p>"
bottom_file = "</div></div></div>" \
               "</div></body></html>"
